package com.example.clase38.entities;

public enum Estado {
    CALENDARIO,POR_COMENZAR,EN_VIVO,FINALIZADO;
}
